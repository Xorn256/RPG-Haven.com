     Hey yo, RPGers. My name is Hibbs, and this is one of many Beta's for my current
project, "Legacy of Heroes".  I just began working on RPG Maker 95, and I LOVE IT. Since I
started playing the great Final Fantasy Series I have dreamed of making a RPG of my own.

     This is the third and probably the most surprising realease. Two major glitches were found!
I elminated them immediatly. Thanks to RPG-Haven for distribuing my game! And to Boney Dragon
for support. There isn't a super duper much more done, like I said, these are Beta's. Stay tuned.

     'Nuff talking, here is the installation procedure:
1. Create a New Game in RPG95 named "Legacy of Heroes".
2. Unzip all files in this .zip to the "Legacy of Heroes" file.
3. Create a subdirectory in the "Legacy of Heroes" named "Sfx" and place all midis and wavs
there.
4. Load it up and play.

     By the way, don't steal from me. Don't do it. It's wrong and you would be dishonoring
yourself as an RPer if you steal. This game has had countless hours worked upon it and
people stealing my files makes me feel... frustrated and less more likely to work on this
game.

(Note: All version numbers have changed, due to the fact I have created a simpler and effective
mathematical system for what my realease is. So don't freak out.)
-----Version History----------------------------------------------------------------------------

~v 0.1~
-1/4 World Map laid out
-Alexandria complete
-Windhem structures up
-Three monsters
-Half the items, weapons, and armor complete
-Main characters established
-First realease

~v 0.16~
-INSANE amounts of bug and glitch fixes
-Alexandria updated
-Windhem complete
-Windhem Forest complete

~v 0.24~
-Alexandria updated
-Windhem updated
-Tanx complete
-Windhem Forest updated
-Mt. Pinsir structure up
-More monsters
-All the items, weapons, and armor complete
-Rynn added
------------------------------------------------------------------------------------------------

     Send ANY, I do mean ANY, questions, comments, suggestions, or congrats to:
PikakiX@aol.com
27452501 on ICQ
XTheHibbs on AIM
Please do mail me any errors or glitches you find! Even tiny ones!

Legacy of Heroes �1999 M'n'B Productions