This is a tileset for Rpg Maker95.
It's used for Flying Killers, the game i'm working on right now.

To Install:
1. Unzip into the folder in which your game you want this tileset to be
used on but make sure that you didn't do anything with the game yet.
2. Just let it go over everything because it don't matter anyway
3. Enjoy this awesome tileset






Thefinal13

Email me at Thefinal13@hotmail.com

Special thanks to:
Kanji Hack for translating this wonderful Rpgmaker you can go to their
website at http://www.barraton.demon.co.uk/khack

Rpg Haven for putting a whole bunch of awesome Rpg related stuff on
it and you can go to their website at http://rpg-haven.com
