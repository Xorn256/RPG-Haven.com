Phoenix Knight Readme

Create a new game with the name Knights using RPG Maker 95. Then unzip these files into that directory.

E-mail any bug reports or suggestions to oologahq@aol.com.

Game Status: About 20% completed.

Changes Made Since Last release:

-Improved intro sequence.
-Changed some spelling errors.
-Lessened difficulty of Ogre Mountain.
-Fixed camping bug in Sprite Forest.
-Added new area, Priory Area, to the main map.
-Added new town, Priory.
-Added Tal's House.
-Added the Priory Mines Dungeon.
-Added 2 new characters, Col and Mab.
-Added some new sound effects.
-Reduced the size of intro bitmaps by making them 256 color. Less quality but also less size.
-Reduced the power of ability improvement items.
-Added some new items.