bleem!(TM) TRIAL VERSION

(c) Copyright 1998-1999 bleem, LLC

=============================================================

Welcome to the bleem! demo version!

This file contains as much information as we could think of
about new bleem! for the PC.

For more information on installation, troubleshooting, and
compatibility, check out the bleem! web page at www.bleem.com.


=============================================================

                          CONTENTS

=============================================================

1.  About this demo

2.  System Requirements

3.  Optimizing Performance

4.  3D Accelerator Notes

5.  How to tell if you need new drivers

6.  Legal Crap


=============================================================

                    1.   ABOUT THIS DEMO

=============================================================

What this demo includes:

* This demo version of bleem! is intended to give you an
  idea of the performance you can expect from the full
  version of bleem!, with your hardware and configuration.

* While certain features have been disabled to make piracy
  less attractive, this demo has been specifically designed
  to accurately depict performance on your PC. i.e. even
  though sound is disabled, this bleem! demo will not run
  FASTER than the real version, with sound running.  We
  don't want to "bait and switch" any of our users.

* This demo will run all the games the full version runs,
  albeit with certain features disabled.  Try your favorite
  games for speed, comapatibility and overall gameplay and
  judge bleem! for yourself.

* There is a time limit in the bleem! demo version that will
  automatically exit after a short period.

What this demo does not include:

We have disabled the following features in this demo, though
they are fully-functional in the full version of bleem!:

* Full Sound Effects and Music

* Memory Card support

* Direct3D support for 3D Hardware Cards

* Support for Enhanced Processors with MMX and 3DNow!


=============================================================

                  2.   SYSTEM REQUIREMENTS

=============================================================

To run bleem! on your PC, you'll need:

* Pentium 166MHz or higher processor

* Microsoft Windows95 or 98 operating system

* 16MB of RAM (32MB recommended)

* DirectX 6.0 or above

* 1 MB of available hard disk space

* CD-ROM drive

* Windows95 or 98-compatible high-color or better video card

* Windows95 or 98-compatible sound board

* Headphones or speakers for full version


=============================================================

                  3.  OPTIMIZING PERFORMANCE

=============================================================

The most important thing you can do to optimize bleem!'s speed
and performance on any PC is to make sure you have the very
latest drivers available.

bleem! uses DirectX 6.0, so new drivers are essential for
optimum performance.  Be sure to read the next section for
further information!

If you already have directX 6.0 or later installed, continue.
bleem! emulates the functions of several dedicated processors
working in parallel, all on your PC.  As a result, you may be
able to increase performance in various areas by reducing the
load placed on your processor by certain non-game essential
functions.

Quick Tips:

To smooth sound playback during MDEC Movies, try setting the
movie to black-and-white only.  (Colour Movies are disabled
in the demo version.)

If sound is jerky or "drops out", reduce the sampling rate
and the bit level until a more enjoyable level is attained.

On systems with larger monitors, many users get much better
performance operating in "full screen" mode.  (The memory
used by the background texture on your desktop is released
for bleem!)


=============================================================

                   4.  3D ACCELERATOR NOTES

=============================================================

This demo version of bleem! does not include Direct3D support.

For more information on Direct3D and examples of the enhanced
graphics you can achieve using 3D hardware, visit our website
at www.bleem.com.


=============================================================

      5. HOW TO TELL IF YOU NEED TO INSTALL NEW DRIVERS

=============================================================

In general, if our website lists a game as being compatible
with bleem!, it should run on any system that meets our
hardware requirements.

Users who have experienced difficulties have generally been
able to trace the problem back to outdated drivers for video,
sound, or CD-ROM drives.

If bleem! will not launch on your system, if many games that
appear on our compatability list do not run, or if sound and
graphics are jerky, even on a fast system, you probably need
new drivers.

For more information on drivers and where to find the most
current versions, see the "help!" section on our website at
www.bleem.com.

If, after installing DirectX 6.1 and the most current drivers
for your software, you are still experiencing problems, please
email us at support@bleem.com and we will respond as soon as
possible.


=============================================================

                        6.  LEGAL CRAP

=============================================================

The game(s) you are about to play were originally developed
under license by Sony Computer Entertainment for the PlayStation
game console and were not designed to be used on personal
computers.

bleem! is not affiliated with, nor authorized, endorsed or
licensed in any way by Sony Corporation, its affiliates or
subsidiaries.

PlayStation game software sold separately and is not included
with bleem!

No affiliation, partnership, joint-venture or relationship of
any kind or form exists with any other companies, products or
services that may be referenced, and should not be implied or
inferred by any references, or the lack thereof.

PlayStation is a registered trademark of Sony Computer
Entertainment, Inc.  "Sony" is a registered trademark for the
Sony Corporation.

bleem! and the bleem! logo are trademarks of bleem, LLC.

All other trademarks are property of their respective holders.

bleem, LLC does not warrant compatibility with all PlayStation
games.

Games may exhibit some defects, including, but not limited to,
audio and video flaws, which may affect how the games play.

Specifications are for informational purposes only and are
subject to change without notice.
