                                  FCE Ultra
                                    .17

                         http://www.kc.net/~zaik/fceu/


What is new:

        * Mapper 15 added.
        * Mapper 23 improved.
        * Mapper 24 extra sound channels emulation improved(thanks to K. Horton).
        * Mapper 26 extra sound channels now emulated("  "    ").
        * Mapper 119(MMC3-TQROM, used in "High Speed" and "Pin Bot")
          improved/fixed.
        * Mapper 225 added.
        * Mapper 226 added.
        * Save state status bar redesigned.
        * A bug causing the keyboard to not work if sound was not initialized
          has been fixed.
        * VRAM read buffering system added.
        * Strip color burst bit is now emulated.
        * New video mode, 256x224("scanlined").
        * Speed is now limited when using VGA mode 3 or 6.

Contents:

  1.  Basic information
        1.0 What FCE Ultra is.
        1.1 System requirements.
  2.  How to use
        2.0 Starting FCE Ultra
        2.1 What to do once emulation has begun
  3.  Compatibility
        3.0 Notes
        3.1 VS Unisystem Notes
  4.  Extra
        4.0 Contacting the author


1.0)

        FCE Ultra is an NTSC Famicom/NTSC NES emulator for DOS.  It is based
        upon Bero's original FCE source code.  Current features include
        good PPU, CPU, pAPU, expansion chip, and joystick emulation.  Also
        a feature unique to this emulator(at the current time) is authentic
        Game Genie emulation!  Save states and snapshot features also have
        been implemented.  The VS Unisystem is emulated as well.
        
1.1)

        Minimum system requirements:

        Pentium 60
        16 MB RAM
        400 KB free disk space
        MS-DOS 6.0
        VGA adapter

        Recommended system requirements:

        Pentium II 200
        16 MB RAM
        5 MB free disk space
        Joystick/Game Pad
        SVGA adapter with 512 KB of RAM
        Sound Blaster
        Windows '95/'98(long file name support)


2.0)

        At a DOS prompt in the directory where the executable is, simply start
        FCE Ultra using the following format:

        fceu <arguments> romimage.nes


        <arguments> can be one or more of the following:

        -vgamode x      Select VGA mode(all are 8 bit).
                        1 = 256x240
                        2 = 256x256
                        3 = 256x256(with scanlines)
                        4 = 640x480(with scanlines)
                        5 = 640x480(T.V. emulation)
                        6 = 256x224(with scanlines)

        -soundmode x    Select sound status
                        0 = Silence
                        1 = Sound Blaster Sound

        -novsync        No sync to VGA VBlank
        -nojoy          Force non-use of joystick.
        -gg             Activate Game Genie emulation.

2.1)

        Once emulation has begun, play as normal.  The mapping of controls
        is:

        Control                 B
        Alt/X                   A
        Enter/Return            Start
        Tab                     Select
        Cursor Down             Down
        Cursor Up               Up
        Cursor Left             Left
        Cursor Right            Right
        C                       Insert Coin.
        V                       View status of dip switches.
        0-9                     Select save state.
        D                       Toggle dip switch modifications allowed
                                (toggles save state selection abilities).
        `                       Full speed ahead, cap'n!
        Caps Lock               Switch between virtual joysticks.
        1-8(VS Unisystem)       Toggle dip switches.

        F5/F7                   Save/Load state.
        F9                      Save screen snapshot.
        ESC/F12                 End emulation.

3.)

        FCE Ultra emulates the NES's pAPU/PPU/CPU well,
        even though there are some bugs.  Bugs will be fixed when they can
        be located and a suitable fix discovered.

        FCE Ultra currently supports the following mappers(many partially):

        0,1,2,3,4,7,8,9,10,11,13,15,16,17,18,19,21,22,23,24,25,26,32,34,47,64,
        65,66,67,68,69,71,73,76,78,79,80,85,90,99,119,151,225,226

3.0)

        FCE Ultra is out of "Beta" stages, but please note that this software
        can be unstable at times.
        Ex:  it expects most memory allocations, file writes, etc. to work.
        If they don't, problems will arise.
        
        If FCE Ultra is too slow for you, try using "-vgamode 3" or
        "-novsync" on the command line.

        FCE Ultra will automatically calibrate your joystick at start up.
        Not touching anything on your joystick is imperative during start up.
        Automatic calibration will work well for most people; however, if
        you encounter problems, please email me and I might consider adding an
        manual calibration option.


        Sound Blaster sound output requires that the 'BLASTER' environment
        variable is set.  To set it(permanently), add the following line
        to your autoexec.bat file:

        set BLASTER=A240 I5 D1

        Where 240(hexadecimal) is the sound blaster's base I/O address, 5
        is the IRQ number, and 1 is the 8-bit DMA channel.  Please note that
        setting any of these incorrectly can cause annoyances such as
        system lockups, so set them correctly, especially the base I/O
        address, since this can cause a loss of data if set incorrectly.

        Occasionally, an interrupt generated by the Sound Blaster will be
        "missed".  This usually occurs after file operations, like
        saving/loading states.  It seems to occur more often in multitasking
        environments.  I have added code that corrects the problem
        should an interrupt be "missed", but it hasn't been tested very much.
        If you're using FCE Ultra and the sound stops sometimes when you're
        using it, please contact me.


        Some games incorrectly have the 4-screen VRAM bit set in the iNES
        header.  This will result in graphical corruption, especially during
        scrolling.  Clear this bit to fix the problem.


        Sometimes in Windows 98(maybe 95, I haven't checked), your keyboard
        might "freak out" when using FCE Ultra.  All letters might be
        capitalized when the caps lock key hasn't been pressed, pressing "F"
        might bring up a "File Find" Window, etc.  This isn't a bug in FCE
        Ultra.  It's a bug with how Windows 98 handles DOS programs.  To
        fix it, press control, alt, shift, caps lock, num lock, scroll lock,
        etc. in various combinations.  After a minute or so, your keyboard
        should be fine.  If this fails, place your arm on the keyboard,
        making sure that MANY keys are depressed.  Move your arm around.
        This isn't a joke; it really does work.


3.1)

        The VS Unisystem is a fairly difficult system to emulate, due to
        the newness of it(to emulation authors).  Here is how to use VS
        Unisystem emulation on FCE Ultra:

          ROM Images:

           * All VS Unisystem ROM images should have the VS Unisystem bit set.
           * VS Unisystem games that are about 49,000 bytes in size should
             use mapper 99(CHR bank select via $4016).
           * Other VS Unisystem games will use other mappers.  Here is a short
             list:


               CastleVania - 2
               Dr. Mario   - 1
               Goonies     - 151
               Gradius     - 151
               Platoon     - 68

          Running:
           
           * Use the C key to insert a coin.
           * Keys 1-8 control the DIP switches(after pressing D).

          Palette(s):

           * The colors in many VS Unisystem games may be incorrect.  This
             is due to each game having its own PPU, and thus using a
             different palette than games that use a different PPU.


4.0)

        I can be reached via email at zaik@kc.net.



               
