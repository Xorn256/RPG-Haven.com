-#######----#######------#####---                                 
-#      #---#      #----#     #--                              9999  555555
-# ####  #--# ####  #--# #######- .   .   .   .  . .___ .__   9    9 5
-# ####  #--# ####  #--# #------- |\ /|  / \  | /  |    |  )  9    9 5
-#      #---#      #---# #######- | | | |---| |<   |--- |--    99999 55555 
-# # ###----# #####----# #     #- |   | |   | | \  |    | \        9      5
-# ##  #----# #--------# ####  #- |   | |   | |  \ |___ |  \       9      5 
-# #-#  #---# #---------#     #--                             99999  55555 
-###--####--###----------#####---                                 

  //////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
 //////////// RPG Maker 95: KanjiHack Translation Notes \\\\\\\\\\\\\\\\\\\\
///////////////////// by Richard "TNomad" Perrin \\\\\\\\\\\\\\\\\\\\\\\\\\\\
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\//////////////////////////////////////////
 \\\\\\\\\\\\\\\\\\\ PATCH RELEASE 6 - 12/11/98 /////////////////////////////
  \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\////////////////////////////////////////

[[[[[[[[[[ CONTENTS ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]

1 - INTRODUCTION
2 - INSTALLATION *IMPORTANT*
3 - MAKING GAMEDISKS *IMPORTANT*
4 - TRANSLATION STATUS
5 - WIERD DASHES ALL OVER THE PLACE
6 - ABOUT OUR GROUP
7 - CREDITS
8 - LINKS

[[[[[[[[[[ INTRODUCTION ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]

RPG Maker 95, as the name imlpies, is an RPG creation tool for Windows 95.
It was orginally released by ASCII in Japan, an English translation has never
previously been avaialable in the US/UK.

Our group, KanjiHack, has been working on this project for some months and
has come up with this translation of the program to be made freely avaialable
to the public. This translation is not perfect, there are a LOT of
abbreviations, but we hope to improve on this over time. (The latest versions
of our translation is available at our web-page, see bottom of the document)

Unlike most translations this his been a one person job, it could have been
done as a group but we decided for various reasons it would be a lot quicker
of one person did the work. But, although I have done this translation, I
cannot take all the credit. It would not have been possible without the
efforts of many others. (See credits section)
                                                               --- TNomad

[[[[[[[[[[ INSTALLATION ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]

To run correctly the program MUST be installed to the directory \RPG95 on
your MAIN hard-drive which is almost always C:, this is because the CD crack
always looks at the first hard-drive it finds. (This shouldn't be a problem
for most of you)

The self-extracting archives the program is stored in automatically create
the directory \RPG95 so when it asks where to install it just install it
to C:\ NOT C:\RP95.

[[[[[[[[[[ MAKING GAMEDISKS ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]

There is a slight problem with RPG Maker 95 when compiling your games in
Gamedisks. This is a wierd problem, I have no idea why but to make a gamedisk
you must do the following:

1) Decide where you want your gamedisk to be located and make a directory/
folder called GAMEDISK. (E.G. If you have a game called Test you might want
to make the folder/directory C:\RPG95\Test\GAMEDISK)

2) Load up your game in RPG Maker 95 and select the [File] menu and click on
[Make Game Disk...]

3) [Browse] or type in the location of the gamedisk folder. (E.G. following
the previous example that would be C:\RPG95\Test *NOT* C:\RPG\Test\GAMEDISK)

4) Select [Start] and in a few minutes your gamedisk will be automatically
made and put into the GAMEDISK folder/directory.

[[[[[[[[[[ TRANSLATION STATUS ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]

*************************************
* PHASE 1 * Main Translation *  98% *
*************************************
* PHASE 2 * Fix Abreviations *   0% *
*************************************
* PHASE 3 * Cracking         * 100% *
*************************************
* PHASE 4 * Documentation    *  20% * (NOT INCLUDED YET)
*************************************

The abbreviations will be done over time but are not expected to be complete
particularly soon.

[[[[[[[[[[ WIERD DASHES ALL OVER THE PLACE ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]

When using this program you will probably notice - marks after text. The
reason for this is part of the translation, the dashes represent spare text
space. These are there for reference when I start messing with the text
pointers to lengthen abbreviations. Because I will need to know where the
extra space is.

[[[[[[[[[[ ABOUT OUR GROUP ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]

KanjiHack is an Internet translation group established August '97. Although
it is unintentional, we seem to specialise in translating Japanese RPG
Makers. Our past projects are "RPG Maker: Super Dante" and "RPG Maker 2"
neither of these projects are fully complete at the moment since most of
our recent work has been on "RPG Maker 95".

What we actually do is find a game where and English version was never made
available in the US/UK and we translate a "patch" for that game so that
people can apply the patch to the game/program to turn it into an Englishv
version. (WE CANNOT SUPPLY THE ACTUAL GAMES SINCE THAT IS PIRACY, WE CAN
ONLY SUPPLY A PATCH, however we can point in the right direction to get
the game since there are other people out there who don't mind distributing
the games)

[[[[[[[[[[ CREDITS ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]

THESE ARE NOT GROUP CREDITS, THESE ARE RPG MAKER 95 RELATED CREDITS

Ch33s3 (dante@anime.demon.co.uk)
 Founded and leads KanjiHack translations
 Managed to get ahold of the Japanese RPG Maker 95
TNomad (TNomad@anime.demon.co.uk)
 Translator/Cracker/Hacker/etc... for RPG Maker 95
Aspetra
 Helped out with webpage and message board

[[[[[[[[[[ LINKS ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]

KanjiHack Translations - http://www.barraton.demon.co.uk
  Our homepage where to find out latest translations.

RPG Haven - http://www.rpg-haven.com
  KanjiHack Distribution where to find copies of the programs we translate.