     Hey yo, RPGers. My name is Hibbs, and this is the first of many Beta's for my current
project, "Legacy of Heroes".  I just began working on RPG Maker 95, and I LOVE IT. Since I
started playing the great Final Fantasy Series I have dreamed of making a RPG of my own.

     This is my very first, so don't be biased on how the game is going to look in the future
by this realease. It has little to do, and most of the work so far has been typing typing typing.
School is here so things are going slower than usual... but not to worry. I stay up all night
on Fridays to work on this game... and I hope it turns out great.

     'Nuff talking, here is the installation procedure:
1. Create a New Game in RPG95 named "Legacy of Heroes".
2. Unzip all files in this .zip to the "Legacy of Heroes" file.
3. Create a subdirectory in the "Legacy of Heroes" named "Sfx" and place all midis and wavs
there.
4. Load it up and play.

     By the way, don't steal from me. Don't do it. It's wrong and you would be dishonoring
yourself as an RPer if you steal. This game has had countless hours worked upon it and
people stealing my files makes me feel... frustrated and less more likely to work on this
game.

-----Version History----------------------------------------------------------------------------

~v 0.06~
-1/4 World Map laid out
-Alexandria complete
-Windhem frames set up
-Three monsters to fight
-Half the items, weapons, and armor complete
-Main characters established
-Alpha version

~v 0.13~
-Numerous bug and glitch fixes
-Alexandria updated
-Windhem complete
-Monster encounter rate fixed
-First realease
------------------------------------------------------------------------------------------------

     Send ANY, I do mean ANY, questions, comments, suggestions, or congrats to:
27452501 on ICQ
XTheHibbs on AIM
And please, no typo or simple error remarks, cause sooner or later I'll stumble upon them and
fix 'em right up (Unless you got a lot, more than 5, then it's okay to).

Legacy of Heroes �1999 M'n'B Productions