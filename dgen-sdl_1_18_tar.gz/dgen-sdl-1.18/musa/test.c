#include <stdio.h>
#include "m68k.h"

/* Read from anywhere */
int  m68k_read_memory_8(int address) { (void)address; return 0; }
int  m68k_read_memory_16(int address) { (void)address; return 0; }
int  m68k_read_memory_32(int address) { (void)address; return 0; }

/* Read data immediately following the PC */
int  m68k_read_immediate_8(int address)  { (void)address; return 0; }
int  m68k_read_immediate_16(int address) { (void)address; return 0; }
int  m68k_read_immediate_32(int address) { (void)address; return 0; }

/* Read an instruction (16-bit word immeditately after PC) */
int  m68k_read_instruction(int address) { (void)address; return 0; }

/* Write to anywhere */
void m68k_write_memory_8(int address, int value) { (void)(address+value); }
void m68k_write_memory_16(int address, int value) { (void)(address+value);}
void m68k_write_memory_32(int address, int value) { (void)(address+value);}

int main()
{
  int ret;
  m68k_pulse_reset(NULL);

  while (1)
  {
    ret=m68k_execute(8000*1000);
    printf ("executed %d clks\n",ret);
  }

  return 0;
}
