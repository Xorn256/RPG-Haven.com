/*
	Interface routine for 68kem <-> Mame

*/

#include "m68000.h"
#include "d68k.h"
#include "cpuintrf.h"

#ifdef WIN32
#define CONVENTION __cdecl
#else
#define CONVENTION
#endif

/* Use the x86 assembly core */
typedef struct
{
    int   d[8];             /* 0x0004 8 Data registers */
    int   a[8];             /* 0x0024 8 Address registers */

    int   usp;              /* 0x0044 Stack registers (They will overlap over reg_a7) */
    int   isp;              /* 0x0048 */

    int   sr_high;          /* 0x004C System registers */
    int   ccr;              /* 0x0050 CCR in Intel Format */
    int   x_carry;          /* 0x0054 Extended Carry */

    int   pc;               /* 0x0058 Program Counter */

    int   IRQ_level;        /* 0x005C IRQ level you want the MC68K process (0=None)  */

    /* Backward compatible with C emulator - Only set in Debug compile */

    int   sr;

    int (*irq_callback)(int irqline);


    int   previous_pc;      /* last PC used */

    						/* This holds the previous opcode address used */
                            /* it is currently only updated on RET opcode  */
                            /* as Indiana Jones needs it for the slapstic  */


    int vbr;                /* Vector Base Register.  Will be used in 68010 */
    int sfc;                /* Source Function Code.  Will be used in 68010 */
    int dfc;                /* Destination Function Code.  Will be used in 68010 */

} m68k_cpu_context;


static unsigned char m68k_reg_layout[] = {
	M68K_PC, M68K_ISP, -1,
	M68K_SR, M68K_USP, -1,
	M68K_D0, M68K_A0, -1,
	M68K_D1, M68K_A1, -1,
	M68K_D2, M68K_A2, -1,
	M68K_D3, M68K_A3, -1,
	M68K_D4, M68K_A4, -1,
	M68K_D5, M68K_A5, -1,
	M68K_D6, M68K_A6, -1,
	M68K_D7, M68K_A7, 0
};

static unsigned char m68k_win_layout[] = {
	48, 0,32,13,	/* register window (top right) */
	 0, 0,47,13,	/* disassembler window (top left) */
	 0,14,47, 8,	/* memory #1 window (left, middle) */
	48,14,32, 8,	/* memory #2 window (right, middle) */
	 0,23,80, 1 	/* command line window (bottom rows) */
};

m68k_cpu_context regs;

extern void CONVENTION M68KRUN(void);
extern void CONVENTION M68KRESET(void);

/********************************************/
/* Interface routines to link Mame -> 68KEM */
/********************************************/

void m68000_reset(void *param)
{
	memset(&regs,0,sizeof(regs));

    regs.a[7] = regs.isp = cpu_readmem24_dword(0);
    regs.pc   = cpu_readmem24_dword(4) & 0xffffff;
    regs.sr_high = 0x27;

	#ifdef MAME_DEBUG
		regs.sr = 0x2700;
	#endif

    M68KRESET();
}


void m68000_exit(void)
{
	/* nothing to do ? */
}


int  m68000_execute(int cycles)
{
	if (regs.IRQ_level == 0x80) return cycles;		/* STOP with no IRQs */

	m68000_ICount = cycles;

#ifdef MAME_DEBUG
    do
    {
		#ifdef TRACE68K 							/* Trace */

        if (errorlog)
        {
			int mycount, areg, dreg;

            areg = dreg = 0;
	        for (mycount=7;mycount>=0;mycount--)
            {
            	areg = areg + regs.a[mycount];
                dreg = dreg + regs.d[mycount];
            }

           	fprintf(errorlog,"=> %8x %8x ",areg,dreg);
			fprintf(errorlog,"%6x %4x %d\n",regs.pc,regs.sr & 0x271F,m68000_ICount);
        }
		#endif

		if (mame_debug)
        {
        	int StartCycle = m68000_ICount;

			MAME_Debug();

            M68KRUN();

            if (regs.IRQ_level & 0x80)
    			m68000_ICount = 0;
            else
				m68000_ICount = StartCycle - 12;
        }
        else
			M68KRUN();

    } while (m68000_ICount > 0);

#else

	M68KRUN();

#endif /* MAME_DEBUG */

	return (cycles - m68000_ICount);
}


unsigned m68000_get_context(void *dst)
{
	if( dst )
		*(m68k_cpu_context*)dst = regs;
	return sizeof(m68k_cpu_context);
}

void m68000_set_context(void *src)
{
	if( src )
		regs = *(m68k_cpu_context*)src;
}

unsigned m68000_get_pc(void)
{
    return regs.pc;
}

void m68000_set_pc(unsigned val)
{
	regs.pc = val;
}

unsigned m68000_get_sp(void)
{
	return regs.isp;
}

void m68000_set_sp(unsigned val)
{
	regs.isp = val;
}

unsigned m68000_get_reg(int regnum)
{
    switch( regnum )
    {
		case M68K_PC: return regs.pc;
		case M68K_ISP: return regs.isp;
		case M68K_USP: return regs.usp;
		case M68K_SR: return regs.sr;
		case M68K_VBR: return regs.vbr;
		case M68K_SFC: return regs.sfc;
		case M68K_DFC: return regs.dfc;
		case M68K_D0: return regs.d[0];
		case M68K_D1: return regs.d[1];
		case M68K_D2: return regs.d[2];
		case M68K_D3: return regs.d[3];
		case M68K_D4: return regs.d[4];
		case M68K_D5: return regs.d[5];
		case M68K_D6: return regs.d[6];
		case M68K_D7: return regs.d[7];
		case M68K_A0: return regs.a[0];
		case M68K_A1: return regs.a[1];
		case M68K_A2: return regs.a[2];
		case M68K_A3: return regs.a[3];
		case M68K_A4: return regs.a[4];
		case M68K_A5: return regs.a[5];
		case M68K_A6: return regs.a[6];
		case M68K_A7: return regs.a[7];
		case REG_PREVIOUSPC: return regs.previous_pc;
/* TODO: Verify that this is the right thing to do for the purpose? */
		default:
			if( regnum <= REG_SP_CONTENTS )
			{
				unsigned offset = regs.isp + 4 * (REG_SP_CONTENTS - regnum);
				if( offset < 0xfffffd )
					return cpu_readmem24_dword( offset );
            }
    }
    return 0;
}

void m68000_set_reg(int regnum, unsigned val)
{
    switch( regnum )
    {
		case M68K_PC: regs.pc = val; break;
		case M68K_ISP: regs.isp = val; break;
		case M68K_USP: regs.usp = val; break;
		case M68K_SR: regs.sr = val; break;
		case M68K_VBR: regs.vbr = val; break;
		case M68K_SFC: regs.sfc = val; break;
		case M68K_DFC: regs.dfc = val; break;
		case M68K_D0: regs.d[0] = val; break;
		case M68K_D1: regs.d[1] = val; break;
		case M68K_D2: regs.d[2] = val; break;
		case M68K_D3: regs.d[3] = val; break;
		case M68K_D4: regs.d[4] = val; break;
		case M68K_D5: regs.d[5] = val; break;
		case M68K_D6: regs.d[6] = val; break;
		case M68K_D7: regs.d[7] = val; break;
		case M68K_A0: regs.a[0] = val; break;
		case M68K_A1: regs.a[1] = val; break;
		case M68K_A2: regs.a[2] = val; break;
		case M68K_A3: regs.a[3] = val; break;
		case M68K_A4: regs.a[4] = val; break;
		case M68K_A5: regs.a[5] = val; break;
		case M68K_A6: regs.a[6] = val; break;
		case M68K_A7: regs.a[7] = val; break;
/* TODO: Verify that this is the right thing to do for the purpose? */
		default:
			if( regnum <= REG_SP_CONTENTS )
			{
				unsigned offset = regs.isp + 4 * (REG_SP_CONTENTS - regnum);
				if( offset < 0xfffffd )
					cpu_writemem24_dword( offset, val );
            }
    }
}

void m68000_set_nmi_line(int state)
{
	/* the 68K does not have a dedicated NMI line */
}

void m68000_set_irq_line(int irqline, int state)
{
    regs.IRQ_level = 0; /* ASG: remove me to do proper mask setting */

	if (state == CLEAR_LINE)
	{
		regs.IRQ_level &= ~(1 << (irqline - 1));
	}
	else
	{
		/* the real IRQ level is retrieved inside interrupt handler */
        regs.IRQ_level |= (1 << (irqline - 1));
	}
}

void m68000_set_irq_callback(int (*callback)(int irqline))
{
	regs.irq_callback = callback;
}

