// DGen/SDL v1.14+
#ifndef __SVGALIB_RC_H__
#define __SVGALIB_RC_H__

// Define the different craptv types
#define NUM_CTV 4 // Include CTV_OFF
#define CTV_OFF       0
#define CTV_BLUR      1
#define CTV_SCANLINE  2
#define CTV_INTERLACE 3

// All the CTV engine names, in string form for the RC and message bar
extern char *ctv_names[];

// Provide a prototype to the parse_rc function in rc.cpp
void parse_rc(const char *file);

#endif // __SVGALIB_RC_H__
