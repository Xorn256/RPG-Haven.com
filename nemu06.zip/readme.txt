Nemu64 - Version 0.6
===========================

Contents
1. History
2. Status
3. Quick tutorial
4. Cheats
5. Technical information
6. Planned features for future version
7. Contact us
8. Disclaimer


1. History

What's new in 0.6 (released 9/13/99)
-----------------------
There is so much new. I don't remember everything :). But this should cover most

*** Lemmy ***
 - MUCH higher game support. This is the most compatible Nemu64 ever :)
 - Support for extra EEProm and Mempack folders, so roms can be directly
     executed from read-only devices like cds or read-only network drives
 - Favourite folders
 - Support for higher resolutions
 - Statefile support
 - Joystick and Keyboard support via DirectInput - highly configurable
 - Alignment support - on newer PCs (PII or better) this can be faster
 - Dynamic TLB - speed increase for non-tlb roms 
 - Several CPU speed ups and bugfixes
 - Added DL/s - this is a more accurate FPS counter. It only works in rcp roms
     (like commercial games and 3d demos)

*** LaC ***
 - Better lle sound support - hardly any gaps now
 - Better PifRAM support (EEProm, RumblePack, Mempack, Controllers)

*** hWnd ***
 - Support for multiple higher resolutions
 - Improved graphics in many games
 - Automatic texture coordinate generation (reflection mapping)
 - Many combine modes added.
 - Much improved optimization of D3D calls (speed)

What's new in 0.5a (released 6/29/99)
-----------------------
Due to heavy demand I added support for roms that were flipped with fliprom.
Nothing else is new in this release.

What's new in 0.5 (released 6/29/99)
-----------------------
This is the first release that plays commercial games (Mario64, WaveRace JAP,
MarioKart, Mortal Kombat Trilogy, Starfox and many more). There is so much new, I
don't know where to start :)

*** Lemmy ***
 - Completed Dynamic Recompilation core
 - Fixed so many cpu bugs. CPU core has been completely rewritten two times since
     the last release
 - Speeded up COP1 and removed bugs
 - TLB support. Requires for Mario, Tetris64 and many more
 - New and much better GUI that makes rom loading much easier
 - Support for cheats. Take a look at chapter 4 to find out how it works
 - UCode detection by CRC. To learn more about it check chapter 5
 - Support for rom-based settings. Right now only eeprom support is stored.
     This allows you to disable eeprom in certain games (WaveRace JAP requires that)
 - Much, much more...

*** hWnd ***
 - HLE-Graphics are done by the DirectX 6.0 video plugin, its current capabilities:
     * Cfb graphics
     * Hardware acceleration if you own an accelerator card
     * Texture caching
     * Support for two ucodes
     * Lighting

*** LaC ***
 - Audio is done by the audio plugin, but it is still the same as in the last
     release. Next version is planned to support hle-audio.
 - Eeprom support, that allows you to use real save games. You can even download
     them from www.dextrose.com and use them in Nemu.
 - Mempack support

This version is not very optimized yet. We expect to get it alot faster with
faster d3d implementation and register caching in the dynarec core. This is the
reason why we are slower than UltraHLE, but that should change in the future. On
the plus site, our cpu core is very accurate because every opcode is completely
emulated as 64 bit opcode.


What's new in 0.02 (released 4/6/99)
-----------------------
This is a pretty big update. The big news is that I have started dynamic
recompilation, which made Nemu64 MUCH faster. Of course, the new core seems to
have some bugs, but almost every cpu-only demo works perfectly.

Also new in this release is more rdp and rsp emulation. Many rdp-demos show
graphics. But there seems to be a timing problem (especially in demot and vnes).
I think the main cpu is simply too fast for the rsp/rdp. I will have to find a
way around that. This problem also occurs in vsfintro; sometimes it shows
the stars, sometimes it doesn't.

I also added the possibility to play a rom without loading it completely into
memory. But it only works, if your rom is not byteswapped.

 - Dynamic Recompilation
 - Bugfixes in the CPU core
 - More bugfixes in the CPU core
 - Even more bugfixes in the CPU core
 - Changed handling of invalid opcodes, so the emu doesn't crash that much anymore
 - DirectDraw plugin (I planned to release a new DIB plugin, too...but I think
     everyone is happy with the DirectDraw plugin)
 - Bugfixes in the DirectSound plugin; doesn't crash anymore if you don't have a
     soundcard
 - Added "dummy sound" plugin, so you can turn sound off if you experience
     any problems. You have to download this plugin seperately and replace the
     file Audio.dll in Nemu64's folder (close Nemu64 before ;-) )
 - Speeded up COP1 (floating point unit)
 - Added some more RSP opcodes
 - Added some sprite types to the RDP Graphics engine
 - Added possibility to let the graphics plugin do RDP. This is generally faster,
     because we can use hardware acceleration, but some demos don't allow that.
     In commercial games it should be no problem. This option can be turned on
     in the settings dialog. Currently it isn't implemented very well.
 - Added speed hacks. With them turned on you can play pong at a very high framerate
 - Added pause function

What's new in 0.012 (released 3/17/99)
-----------------------
New release after one week. I implemented more RCP (RSP/RDP) emulation
and I am getting first results! Mortal Kombat shows up the title screen,
vnes64 "works" (tried with Zelda 1) and Virtual Springfield Site also displays
some nice things. All these RDP roms use the sprite engine of the n64. My emu-
lation for it is very buggy. The reason why I haven't fixed them yet is that
I am going to rewrite my RDP graphics core.

 - Added many RSP opcodes, especially LWC2/SWC2 - Opcodes
 - Added some RDP opcodes like DrawTextureRect and SetTile
 - Added support for SI DMA write (copy from SPIMEM/SPDMEM to RDRAM)
 - changed RDRAM size from 4 to 8 MB (not really necessary, but some games
   have extensions for that)

Please note that I released this version because Nemu will get a major internal
change, because I am now really starting RDP emulation. I will try to get things
working with Direct3D. Maybe I will add OpenGL or Glide later.


What's new in 0.011 (released 3/10/99)
-----------------------
OK...this time's big news is controller #1 support!
You can play pong and see the fractal in fzoom. Also Liner works and
every other demo I tested, too. I can't wait to see the updated compatibility list
on cn64es :-)

 - fixed the rotate bug (LH was wrong)
 - fixed bug in LWL and LWR ==> controllers work  (thanks to Dimitri and LaC!)
 - fixed analog up
 - increased analog stick support: try holding shift while moving the analog
     stick to a direction


What's new in 0.01 (released 3/8/99)
-----------------------
I implemented audio and basic controller support. It works quite fine in about 10 demos.

 - Controllers are partially working....right now they only work in liner. The key mapping is following:
     A,S,X                         : The 3 main buttons
     Cursor UP, DOWN, LEFT, RIGHT  : Analog Stick (always at maximum)
     I,K,J,L                       : C-Buttons (used in liner to control the line)
     T,G,F,H                       : Joypad
     Return                        : Start Button

 - RSP bug fixed....RSP code executes now correctly
 - Almost complete Audio Emulation (missing: 8 (and maybe 4) Bit sound support, only 16 Bit implemented)
 - Internal changes
 - fixed problem with vi interrupt
 - changed the way the screen refreshes ==> Liner works

What's new in 0.009
-----------------------
 - more RSP, no results yet
 - did some more cpu and cop1 opcodes, now almost all important opcodes are implemented
 - implemented automatic crc fix
 - changed many internal things
 - speed increased again
 - bugfixes....(for example rpa bug is fixed)

What's new in 0.008
-----------------------
 - Better PI Interrupt --> many more demos work
 - more rsp emulation, some roms use rsp :-) but crash :-(

What's new in 0.007b
-----------------------
 - Bugfixes

What's new in 0.007a
-----------------------
 - fixed the 640x480 bug
 - fixed a bug in the PI Interrupt

What's new in 0.007
-----------------------
 - Implemented an opcode to see the title of vnes
 - Speed increase
 - Support for VI_CURRENT_LINE_REG
   --> CRAP #1 and #2 work better than in PUR now
 - started rsp emulation, but nothing works yet (maybe some rsp demos crash now)
 - some other things

What's new in 0.006
-----------------------
 - You don't have to restart Nemu64 in order to load another rom.
 - You can close a rom now
 - minor speed increase
 - Editor for rom headers - check it out
 - Added a few opcodes of the fpu (now about 42% complete)
 - Fixed a major bug in the SI Interrupt. Now SP_CRAP runs partially


2. Status (Status of 0.5)
The main cpu is about done. All important opcodes are done in asm.

Audio (no hle audio, required for games) and first controller are implemented.

RCP is simulated via HLE, so almost every demo runs and many games work.

EEProm and Mempack are supported and use savefiles.


3. Quick (very quick) tutorial
Start the emu, select a rom and double click it. Everything should work :)


4. Cheats
This is a short explanation how to use cheats in Nemu64.

Nemu64 has a built in search function so you should be able to find many cheats
very easily. To understand how it works I give an example, how I found out the
cheat to the points in Pong.

First you have to start pong in Nemu64. Now try to win one round in pong so you
get one point. At this time somewhere in the emulated memory must be the value
'1'. Now enter the cheat window. In the "search cheat" input field you enter '1'
and click on search. After a very short time nemu displays how many times it found
that value. I got 58 hits. One of these memory locations is the one we search for,
but testing 58 would be some work. So press close and then close the cheat window.
Play pong until you have '2' points. Enter cheat window again and search for '2'.
You should now find exactly 1 hit (0x01C068). This is the memory location of the
Left Player Points. Name this location and click add. Now you can enter any value
you want to cheat the game :)

You can also add cheats of UltraHLE to Nemu64, but they need to be converted a
little bit. Let me explain the structure of an UltraHLE cheat first. This is an
example of the cheat that gives Mario 99 lifes:

patch=-1, 8033B21D, byte 99

'patch=-1' means the cheat is assigned on every frame
'8033B21D' is the memory location of the cheat
'byte' tells UltraHLE to use only one byte
'99' is the value to put in (in this example 99 lifes)

A difference between UltraHLE and Nemu64 cheats is that UltraHLE assigns cheats
on every frame, but in Nemu64 you decide when to change that value and you enter
a value at runtime. To use this cheat we need to tell Nemu64 the memory address.
To do that you need to modify Nemu64.ini manually. To add Mario-cheats you need
to modify the section '[SUPER MARIO 64 - Cheats]'. The converted Nemu64 cheat
would be:

33B21D=B,Lifes

The memory address in UltraHLE has '80' as leading digits. They need to be
deleted for Nemu64. 'B' means we are using a byte cheat (b=byte, w=word,
d=dword, q=qword). 'Lifes' is the descritpion. The value '99' isn't needed as
you enter the new value in the cheat window.


5. Technical information

UCode Detection
------------------
Nemu64 High Levels some functions to increase speed. This technique is called
HLE and was used first by Epsilon and RealityMan in UltraHLE. When using hle you
don't try to emulate hardware but instead you simulate the software running on it.
This results in much higher speed but there is the big disadvantage that not every
game uses the same software to show its graphics and produce its sound. The only
code that we simulate on high level is called the ucode. We have to support
several ucodes and detect which one is needed. Our detection works
by calculating a checksum and comparing that with a list. Many roms have the
same crc, but even ucodes with a different checksum might be compatible. So we
assign an ID to that crc that tells Nemu64 which simulator code to use. These
ID's are stored in Nemu64.ini. For example:

333F3B56=1    ; 'SUPER MARIO 64'

'333F3B56' is the checksum
'1' is the ID thats is assigned to that ucode.

In Nemu64 0.5 the IDs 1 and 2 are available. If 1 doesn't work try 2 :)

6. Planned features for future version
  - Complete list of all ucodes
 ok Register Caching
  - Faster D3D gfx
 ok Controller Configuration Dialog
  - Netplay
 ok Audio HLE
  - Support for more UCodes
 OK Savestates (memory dumps)
 OK Faster TLB
  - 64 Bit FPR
 OK High resolution screen modes
  - cfb-rcp mixing

  
7. Contact us
If you want to contact me, please go to #nemu64, #n64emu or #emuunlim on EFNet.
I don't provide my email address here, because I don't want to get tons of mails.
You should also know, that I won't give you any commercial roms, because they are
copyrighted. If you want to send an email you can send to nemu64@bigfoot.com, which
is kept by TheN64Fan.

hWnd can be contacted either on #nemu64 or at his email redirect hWnd@bigfoot.com.
Please do not send rom requests, or requests for copies of the program. All mail 
will be read, but there is no time to reply to all of it.

The official site is www.emuunlim.com/nemu64. It is designed by ___Z___, who
also did the cool new logo. His email address is zakai@flashmail.com.

8. Disclaimer
We do not have any association with Nintendo, or any of its affiliates.  This
program was developed for non-commercial use and is not intended to compete with
the Nintendo 64. The name Nintendo and various other names and service marks are
owned by either Nintendo or their respective owners. No guarantee is given that 
this program will run any specific rom, or even that it will run anything at all.
We do not take responsiblility for any crashes or loss of data or work that may
result from using this program. 


                                                               Greetings Lemmy
