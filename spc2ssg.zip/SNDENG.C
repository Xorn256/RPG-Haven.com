#include <stdio.h>
#include <allegro.h>
#include <conio.h>
#include <audio.h>

#define EV_NOTHING    0
#define EV_KEYON      1
#define EV_KEYOFF     2
#define EV_CHANGEVOL  3
#define EV_CHANGEFREQ 4

// auxiliary engine !
/*
void DSP_init2();
void DSP_close2();
void update_Sound2();
*/

unsigned char  MasterVolume, MasterPanning, Stereo;

HAC            Voice[8];
LPAUDIOWAVE    Sample[256];
unsigned char  sample_cnt;

int            Sound_output;

static inline int get_frequency(int snes_tone)
{
  if (snes_tone == 0x1000)
    return 32768;
  else
    return (32768 * snes_tone) / 0x1000;
}


void exec_command(unsigned char cmd, unsigned char channel,
                  unsigned short arg1, unsigned char arg2, unsigned char arg3)
{
/*
#ifdef __GO32__
  if (Sound_output == 9) { update_Sound2(value); return; }
#endif
*/
  switch (cmd) {
    case EV_CHANGEFREQ:
      ASetVoiceFrequency(Voice[channel], get_frequency(arg1)); break;

    case EV_CHANGEVOL:
      ASetVoiceVolume(Voice[channel], MIN(64,MasterVolume*arg1/127)); break;

    case EV_KEYON:
      APlayVoice(Voice[channel], Sample[arg2]);
      ASetVoiceFrequency(Voice[channel], get_frequency(arg1));
      ASetVoiceVolume(Voice[channel], MIN(64,MasterVolume*arg3/127)); break;

    case EV_KEYOFF:
      AStopVoice(Voice[channel]); break;
  }
}

void Sound_update()
{
#ifdef __GO32__
  if (Sound_output == 9) return;
#endif
  AUpdateAudio();
}

void Sound_pause()
{
  int a;

  for (a = 0; a < 8; a++) {
    AStopVoice(Voice[a]);
  }
}

void Sound_resume()
{
  int a;

  for (a = 0; a < 8; a++) {
    AStartVoice(Voice[a]);
  }
}

int Sound_get_device()
{
  AUDIOCAPS      caps;

  if (Sound_output == 0) return 0x0000;
#ifdef __GO32__
  if (Sound_output == 9) return 0x0009;
#endif

  AGetAudioDevCaps(Sound_output,&caps);

  switch (caps.wProductId) {
    case AUDIO_PRODUCT_NONE:    return 0x0000;
    case AUDIO_PRODUCT_SB:      return 0x0001;
    case AUDIO_PRODUCT_SB15:    return 0x0001;
    case AUDIO_PRODUCT_SB20:    return 0x0001;
    case AUDIO_PRODUCT_SBPRO:   return 0x0001;
    case AUDIO_PRODUCT_SB16:    return 0x0001;
    case AUDIO_PRODUCT_AWE32:   return 0x0002;
    case AUDIO_PRODUCT_WSS:     return 0x0006;
    case AUDIO_PRODUCT_ESS:     return 0x0007;
    case AUDIO_PRODUCT_GUS:     return 0x0005;
    case AUDIO_PRODUCT_GUSDB:   return 0x0005;
    case AUDIO_PRODUCT_GUSMAX:  return 0x0004;
    case AUDIO_PRODUCT_IWAVE:   return 0x00FF;
    case AUDIO_PRODUCT_PAS:     return 0x0003;
    case AUDIO_PRODUCT_PAS16:   return 0x0003;
    case AUDIO_PRODUCT_LINUX:   return 0x00FF;
  }

  return 0x00FF;
}

void Sound_init()
{
  int a, k;
  AUDIOINFO      info;
  AUDIOCAPS      caps;

/*
#ifdef __GO32__
  if (Sound_output == 9) { DSP_init2(); return; }
#endif
*/
  AInitialize();

  printf("\nSelect the audio device:\n\n");
  for (k = 1;k < AGetAudioNumDevs();k++) {
    if (AGetAudioDevCaps(k,&caps) == AUDIO_ERROR_NONE)
    printf("  %2d. %s\n",k,caps.szProductName);
  }
  printf("\n");
  Sound_output = getch() - '0';

  info.nDeviceId   = Sound_output;
  info.wFormat     = AUDIO_FORMAT_16BITS | AUDIO_FORMAT_MONO;
  info.nSampleRate = 44100;

  AOpenAudio(&info);
  Sound_output = info.nDeviceId;

  AOpenVoices(8);

  for (a=0;a<8;a++) {
    ACreateAudioVoice(&Voice[a]);
    ASetVoicePanning(Voice[a],128);
  }

  for (a=0;a<32;a++) {
    Sample[a]=(LPAUDIOWAVE)malloc(sizeof(AUDIOWAVE));
    Sample[a]->nSampleRate = 32768;
    Sample[a]->lpData      = NULL;
  }
}

void Sound_addsample(int num, int length, int loopstart, unsigned char *samp)
{
  Sample[num]->wFormat = AUDIO_FORMAT_16BITS | AUDIO_FORMAT_MONO;
  if (loopstart) {
    Sample[num]->wFormat |= AUDIO_FORMAT_LOOP;
    Sample[num]->dwLoopStart = loopstart;
    Sample[num]->dwLoopEnd   = length;
  } else {
    Sample[num]->dwLoopStart = Sample[num]->dwLoopEnd = 0;
  }
  Sample[num]->dwLength = length;

  ACreateAudioData(Sample[num]);
  memcpy(Sample[num]->lpData, samp, length);
  AWriteAudioData(Sample[num], 0L, Sample[num]->dwLength);
}

void Sound_close()
{
  int a;
/*
#ifdef __GO32__
  if (Sound_output == 9) { DSP_close2(); return; }
#endif
*/

  for (a = 0; a < 8; a++) {
    AStopVoice(Voice[a]);
    ADestroyAudioVoice(Voice[a]);
  }

  for (a = 0; a < 32; a++) {
    if (Sample[a]->lpData) ADestroyAudioData(Sample[a]);
    free(Sample[a]);
  }

  ACloseVoices();

/* close audio device */
  ACloseAudio();
}

