#include <audio.h>
#include <stdio.h>
#include <conio.h>
#include <allegro.h>

FILE *f;

int samples_pos, sample_length, sample_loopstart;
char *samp;
int i;
unsigned short old_time_pos, time_pos;
unsigned char channel, command, arg2, arg3, ch;
unsigned short arg1;

unsigned char sng_exit;

extern unsigned char MasterVolume;

volatile int timer;

void timer_handler()
{
  timer = 1;
}

END_OF_FUNCTION(timer_handler);

int main(int argc, char **argv)
{
  char buf[80];

  printf("\nSSGPLAY v0.1 (c) 1998 Archeide\n");

  if (argc != 2) {
    printf("\n usage : SSGPLAY <file.SSG> \n\n");
    printf("Thanks for using SSGPLAY\n");
    printf("SSGPLAY was made with the 32bits C/C++ compiler DJGPP.\n");
    printf("SEAL sound library (c) Carlos Hasan\n");
    printf("Allegro game library (c) Shawn Hargreaves & co.\n");

    return 255;
  }

  f = fopen(argv[1], "rb");

  fread(&buf, 60, 1, f);

// TO DO : a format test

  Sound_init();

  LOCK_VARIABLE(timer);
  LOCK_FUNCTION(timer_handler);

  i_love_bill = TRUE;

  install_timer();
  install_int(timer_handler, 20);

  printf("Playing...\n");

  fread(&samples_pos, 4, 1, f);

  for (i = 0; i < 32; i++) {
    fseek(f, 64+i*16, SEEK_SET);
    fread(&sample_length, 2, 1, f);
    fread(&sample_loopstart, 2, 1, f);

    samp = (unsigned char *)malloc(sample_length);

    fseek(f, samples_pos, SEEK_SET);
    fread(samp, sample_length, 1 , f);

    Sound_addsample(i, sample_length, sample_loopstart, samp);

    free(samp);
    samples_pos += sample_length;
  }

  fseek(f, 64+32*16, SEEK_SET);

  MasterVolume = 64;

  old_time_pos = 0;
  while (!sng_exit) {
    fread(&time_pos, 2, 1, f);
    while (old_time_pos < time_pos) {
      Sound_update();
      if (timer) {
        old_time_pos++; timer = 0;
      }
    }
    fread(&channel, 1, 1, f);
    fread(&command, 1, 1, f);

    if (command == 0) sng_exit = 1;

    fread(&arg1, 2, 1, f);
    fread(&arg2, 1, 1, f);
    fread(&arg3, 1, 1, f);

    exec_command(command, channel, arg1, arg2, arg3);

    if (kbhit()) ch = getch();
    if (ch == '\e') sng_exit = 1;
  }

  remove_timer();

  Sound_close();

  printf("Thanks for using SSGPLAY\n");
  printf("SSGPLAY was made with the 32bits C/C++ compiler DJGPP.\n");
  printf("SEAL sound library (c) Carlos Hasan\n");
  printf("Allegro game library (c) Shawn Hargreaves & co.\n");

  return 0;
}
