The Company decided to release: Ultra InI version 1E-3 .

Ultra Ini file is featuring:
- Super Mario Karts & Zelda Ultra.InI 1-E2 mistakes corrected.
- InI file reduced to the max (retyped some patches, comments).
- 3 Different InI files (chose the one to install):
�� - First includes everything (huge!)
�� - Second includes everything but Cheats
�� - Third includes everything but non working roms and demos
- Added comments to most of the newest roms.
��(Etail monster works with some gfx probs, APE).
- Added comments to a few old roms and dupes.
�� (Konami puzzle sound + intro, enhanced patch by The Company)
- Top Gear Rally patch enhanced for more stability/speed (The Company)
- Added Partial support to Hybrid Heaven� (The Company)
- New Superman, Zelda, Doom, Quake, Snowboard Kids and Wave Race cheats   Super Mario & Rampage World Tour cheats by: Lone Soldier!
- Mario Kart, Golden Eye, Super Mario cheats codes enhanced and fixed   (Lone Soldier)
- Homebrew packs, Cruisn'USA cheats (APE!)
- Correction to Mace euro patch (Reaper)
-----------------------------------------------------------------
Special note: My new F-Zero X patch has not been added. Why, that 
damned windows reports an illegal operation after a short while.
Also, I hope that a new Banjoo Kazooie patch can be released next time.
For now, it allows MORE gameplay but is kinda unsecure.
Maybe next time? Stay TuNed!
Special Thanks to LONE SOLDIER for his MAJOR support.
-----------------------------------------------------------------
Get our latest releases from our Web Whq:

> The Last Resort < Http://perso.infonie.fr/flying_angel   (U.S)

Mirror #1	    Http://come.to/thelastresort/ (U.s)
Mirror #2           Http://members.xoom.com/Company_91/  (DOWN!)


Email contact:  Domynator@yahoo.com (Submit patches, Web related questions)
                the_company_1991@yahoo.com (techn. problems, InI or Web suggestions)
Or reach me at Dave's classic message board (linked from our site).
Dont bother us with:
- stupid technical questions, check our FAQ first, also available (N64 emulation section). Don't come up with some
- "hey, i want that game to be emulated", "where to find more roms?".
- Troubles with UltraHLE french => Fuck!   Merde!  Scheisse! I am tired
  of this. Get in touch with the author himself.

Most of the roms we've been working on are available at the LAST RESORT.
Ofcourse, this is a hidden DL page with about 600megs of hosted files
for N64, Mame and Bleem!. If you can't find it, then don't even ask for
it. Hint at LINKZ page. Read carefully. under no circumstances, we
will give you the exact URL! ROMZ section will only show you what you
will find in there...
Our ANTI linkers protection is now active! It will hurt BOTH Linkers
& people leeching files linked from us. Try and you will see.

REMEMBER:      A GAME WORTH PLAYING is A GAME WORTH BUYING!

Golden regards are flying to all of our friends and contacts from
the emulation, AMIGA, Pc  & H/P Scene!

Signed XXXX!, wanted Dead or Alive since 1989!
THE COMPANY, born in 1991!


